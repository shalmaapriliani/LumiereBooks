
document.addEventListener('DOMContentLoaded', () => {
    const form = document.querySelector('[data-site-editor-form]');
    if (!form) return;

    form.querySelectorAll('[data-preview]').forEach((field) => {
        const target = document.querySelector(`[data-preview-target="${field.dataset.preview}"]`);
        if (!target) return;
        const update = () => { target.textContent = field.value || ' '; };
        field.addEventListener('input', update);
        update();
    });

    form.querySelectorAll('[data-preview-toggle]').forEach((field) => {
        const target = document.getElementById(field.dataset.previewToggle);
        if (!target) return;
        const update = () => { target.style.display = field.checked ? '' : 'none'; };
        field.addEventListener('change', update);
        update();
    });

    form.querySelectorAll('[data-preview-image]').forEach((field) => {
        field.addEventListener('change', () => {
            const file = field.files && field.files[0];
            const target = document.getElementById(field.dataset.previewImage);
            if (!file || !target) return;
            if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) {
                field.value = '';
                window.alert('Pilih gambar JPG, PNG, atau WEBP.');
                return;
            }
            if (file.size > 4 * 1024 * 1024) {
                field.value = '';
                window.alert('Ukuran gambar maksimal 4 MB.');
                return;
            }
            const reader = new FileReader();
            reader.onload = () => { target.src = String(reader.result); };
            reader.readAsDataURL(file);
        });
    });
});
