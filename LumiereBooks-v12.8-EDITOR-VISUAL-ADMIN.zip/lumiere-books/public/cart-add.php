<?php

declare(strict_types=1);

/*
 * Dedicated AJAX endpoint for adding a book to the cart.
 * It deliberately bypasses the normal page renderer so the response is
 * always JSON (never a redirect or an HTML page).
 */
ob_start();

function lumiere_cart_json(array $payload, int $status = 200): never
{
    while (ob_get_level() > 0) {
        ob_end_clean();
    }

    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('X-Content-Type-Options: nosniff');

    echo json_encode(
        $payload,
        JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE
    );
    exit;
}

register_shutdown_function(static function (): void {
    $error = error_get_last();
    $fatalTypes = [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR];

    if ($error && in_array($error['type'], $fatalTypes, true) && !headers_sent()) {
        lumiere_cart_json([
            'success' => false,
            'message' => 'Terjadi kesalahan pada server saat menambahkan buku. Silakan coba lagi.',
        ], 500);
    }
});

try {
    require dirname(__DIR__) . '/app/bootstrap.php';

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        lumiere_cart_json([
            'success' => false,
            'message' => 'Permintaan tidak valid.',
        ], 405);
    }

    $submittedToken = $_POST['_csrf'] ?? '';
    if (!is_string($submittedToken) || !hash_equals(csrf_token(), $submittedToken)) {
        lumiere_cart_json([
            'success' => false,
            'message' => 'Sesi halaman sudah kedaluwarsa. Muat ulang halaman, lalu coba lagi.',
            'reload' => true,
        ], 419);
    }

    $user = current_user();
    if (!$user) {
        lumiere_cart_json([
            'success' => false,
            'message' => 'Silakan masuk ke akun terlebih dahulu untuk menambahkan buku.',
            'login_required' => true,
        ], 401);
    }

    if (($user['role'] ?? '') !== 'user') {
        lumiere_cart_json([
            'success' => false,
            'message' => 'Keranjang hanya tersedia untuk akun pelanggan.',
        ], 403);
    }

    $bookId = (int) ($_POST['book_id'] ?? 0);
    $quantity = max(1, (int) ($_POST['quantity'] ?? 1));
    if ($bookId < 1) {
        lumiere_cart_json([
            'success' => false,
            'message' => 'Buku yang dipilih tidak valid.',
        ], 422);
    }

    $pdo = db();
    $bookQuery = $pdo->prepare(
        'SELECT id, title, stock FROM books WHERE id = ? AND status = "active" LIMIT 1'
    );
    $bookQuery->execute([$bookId]);
    $book = $bookQuery->fetch();

    if (!$book || (int) $book['stock'] < 1) {
        lumiere_cart_json([
            'success' => false,
            'message' => 'Buku tidak tersedia atau stok sedang kosong.',
        ], 422);
    }

    $existing = $pdo->prepare(
        'SELECT quantity FROM cart_items WHERE user_id = ? AND book_id = ? LIMIT 1'
    );
    $existing->execute([(int) $user['id'], $bookId]);
    $currentQuantity = (int) ($existing->fetchColumn() ?: 0);
    $newQuantity = min((int) $book['stock'], $currentQuantity + $quantity);

    $save = $pdo->prepare(
        'INSERT INTO cart_items (user_id, book_id, quantity)
         VALUES (?, ?, ?)
         ON DUPLICATE KEY UPDATE quantity = VALUES(quantity)'
    );
    $save->execute([(int) $user['id'], $bookId, $newQuantity]);

    lumiere_cart_json([
        'success' => true,
        'message' => 'Buku berhasil ditambahkan ke keranjang!',
        'cart_count' => cart_count(),
        'book_title' => (string) $book['title'],
    ]);
} catch (Throwable $exception) {
    error_log('[Lumiere cart-add] ' . $exception->getMessage());

    lumiere_cart_json([
        'success' => false,
        'message' => 'Buku belum dapat ditambahkan. Periksa koneksi server/database lalu coba lagi.',
    ], 500);
}
