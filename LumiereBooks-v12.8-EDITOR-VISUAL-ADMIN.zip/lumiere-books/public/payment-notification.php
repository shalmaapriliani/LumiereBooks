<?php

declare(strict_types=1);

http_response_code(410);
header('Content-Type: application/json; charset=utf-8');
echo json_encode([
    'status' => 'disabled',
    'message' => 'Ikuti petunjuk pembayaran untuk menyelesaikan pesanan Anda.',
]);
