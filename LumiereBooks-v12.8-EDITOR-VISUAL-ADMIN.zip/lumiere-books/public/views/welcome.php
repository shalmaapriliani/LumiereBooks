<?php
$welcomeSearch = trim((string) ($_GET['q'] ?? ''));
?>
<section class="welcome-fullscreen" aria-label="Selamat datang di Lumière Books">
    <div
        class="welcome-fullscreen-bg"
        role="img"
        aria-label="Suasana meja baca hangat dengan koleksi buku dan perlengkapan membaca"
    >
    </div>
    <header class="welcome-topbar">
        <a class="welcome-brand" href="<?= e(url('welcome')) ?>" aria-label="Lumière Books Beranda">
            <img src="<?= e(asset('logo-lumiere.png')) ?>" alt="">
            <span>
                Lumière Books
            </span>
        </a>
        <nav class="welcome-nav" aria-label="Navigasi utama">
            <a class="is-active" href="<?= e(url('welcome')) ?>">
                Beranda
            </a>
            <a href="<?= e(url('about')) ?>">
                Tentang Kami
            </a>
        </nav>
        <div class="welcome-tools" aria-label="Akses cepat">
            <a href="<?= e(url('books')) ?>" aria-label="Cari buku" title="Cari buku">
                <?= ui_icon('search') ?>
            </a>
            <a href="<?= e(url('login')) ?>" aria-label="Buku favorit" title="Buku favorit">
                <?= ui_icon('heart') ?>
            </a>
            <a href="<?= e(url('login')) ?>" aria-label="Keranjang" title="Keranjang">
                <?= ui_icon('cart') ?>
            </a>
        </div>
    </header>
    <div class="welcome-copy">
        <h1>
            Setiap Buku,
            <br>
            Sejuta Cahaya.
        </h1>
        <div class="welcome-flourish" aria-hidden="true">
            <span>
            </span>
            <b>
                ✦
            </b>
        </div>
        <p>
            Temukan berbagai koleksi buku, alat tulis,
            <br class="desktop-break">
            dan hadiah pilihan untuk menemani
            <br class="desktop-break">
            setiap langkah dan inspirasimu.
        </p>
        <a class="welcome-enter" href="<?= e(url('login')) ?>">
            Masuk
            <span aria-hidden="true">
                →
            </span>
        </a>
        <div class="welcome-promises" aria-label="Keunggulan Lumière Books">
            <div>
                <span class="promise-icon">
                    <?= ui_icon('heart') ?>
                </span>
                <b>
                    Koleksi
                    <br>
                    Lengkap
                </b>
            </div>
            <div>
                <span class="promise-icon">
                    <?= ui_icon('gift') ?>
                </span>
                <b>
                    Cocok
                    <br>
                    untuk Hadiah
                </b>
            </div>
            <div>
                <span class="promise-icon">
                    <?= ui_icon('shield-check') ?>
                </span>
                <b>
                    Pembayaran
                    <br>
                    Aman
                </b>
            </div>
            <div>
                <span class="promise-icon">
                    <?= ui_icon('refresh-cw') ?>
                </span>
                <b>
                    Pengembalian
                    <br>
                    Mudah
                </b>
            </div>
        </div>
    </div>
</section>
