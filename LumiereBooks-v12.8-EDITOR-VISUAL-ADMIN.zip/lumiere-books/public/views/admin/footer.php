</main>
<footer class="admin-footer">
    ©
    <?= date('Y') ?>
    Lumière Books · Admin Panel
</footer>
</div>
</div>
<script src="<?= e(asset('js/app.js')) ?>
">
</script>
    <script src="<?= e(asset('js/redesign.js')) ?>
">
</script>
    <?php if ($page === 'site-editor'): ?>
        <script src="<?= e(asset('js/site-editor.js')) ?>?v=1"></script>
    <?php endif; ?>
    </body>
</html>
