<?php
$editorValue = static fn (string $key): string => (string) ($siteEditor[$key] ?? '');
$editorImage = static fn (string $key): string => (string) ($siteEditorImages[$key] ?? '');
?>
<div class="site-editor-layout">
    <form
        class="site-editor-form"
        method="post"
        action="<?= e(admin_url('site-editor')) ?>"
        enctype="multipart/form-data"
        data-site-editor-form
    >
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="save_site_content">

        <section class="admin-panel site-editor-intro">
            <div class="panel-heading">
                <div>
                    <h2><?= ui_icon('monitor') ?> Editor Tampilan Website</h2>
                    <p>
                        Ubah isi banner, promo, dan halaman Tentang Kami.
                        Tata letak dan desain utama toko tetap dipertahankan.
                    </p>
                </div>
            </div>
            <div class="site-editor-note">
                <strong>Catatan:</strong>
                perubahan baru tampil di website pelanggan setelah tombol Simpan ditekan.
                Gambar yang diunggah disimpan di <code>lumiere-storage/site/</code>.
            </div>
        </section>

        <section class="admin-panel site-editor-section" id="hero-editor">
            <div class="panel-heading">
                <div>
                    <h2><?= ui_icon('image') ?> Banner Beranda</h2>
                    <p>Atur judul utama dan gambar besar pada bagian atas beranda.</p>
                </div>
            </div>
            <label class="site-editor-switch">
                <input
                    type="checkbox"
                    name="site_hero_enabled"
                    value="1"
                    <?= $editorValue('site_hero_enabled') === '1' ? 'checked' : '' ?>
                    data-preview-toggle="hero-preview"
                >
                <span>Tampilkan banner beranda</span>
            </label>
            <div class="site-editor-fields">
                <label>
                    Teks kecil
                    <input
                        type="text"
                        name="site_hero_eyebrow"
                        value="<?= e($editorValue('site_hero_eyebrow')) ?>"
                        data-preview="hero-eyebrow"
                    >
                </label>
                <label>
                    Judul utama
                    <input
                        type="text"
                        name="site_hero_title"
                        value="<?= e($editorValue('site_hero_title')) ?>"
                        data-preview="hero-title"
                    >
                </label>
                <label>
                    Slogan
                    <input
                        type="text"
                        name="site_hero_subtitle"
                        value="<?= e($editorValue('site_hero_subtitle')) ?>"
                        data-preview="hero-subtitle"
                    >
                </label>
                <label class="site-editor-wide">
                    Deskripsi
                    <textarea
                        name="site_hero_description"
                        rows="3"
                        data-preview="hero-description"
                    ><?= e($editorValue('site_hero_description')) ?></textarea>
                </label>
                <label class="site-editor-wide">
                    Gambar banner (JPG, PNG, WEBP · maks. 4 MB)
                    <input
                        type="file"
                        name="hero_image"
                        accept="image/jpeg,image/png,image/webp"
                        data-preview-image="hero-preview-image"
                    >
                </label>
            </div>
        </section>

        <section class="admin-panel site-editor-section" id="sale-editor">
            <div class="panel-heading">
                <div>
                    <h2><?= ui_icon('tag') ?> Promo Diskon</h2>
                    <p>Atur banner promo seperti diskon 30% pada beranda.</p>
                </div>
            </div>
            <label class="site-editor-switch">
                <input
                    type="checkbox"
                    name="site_sale_enabled"
                    value="1"
                    <?= $editorValue('site_sale_enabled') === '1' ? 'checked' : '' ?>
                    data-preview-toggle="sale-preview"
                >
                <span>Tampilkan promo diskon</span>
            </label>
            <div class="site-editor-fields">
                <label>
                    Label kecil
                    <input
                        type="text"
                        name="site_sale_label"
                        value="<?= e($editorValue('site_sale_label')) ?>"
                        data-preview="sale-label"
                    >
                </label>
                <label>
                    Judul promo
                    <input
                        type="text"
                        name="site_sale_title"
                        value="<?= e($editorValue('site_sale_title')) ?>"
                        data-preview="sale-title"
                    >
                </label>
                <label class="site-editor-wide">
                    Deskripsi
                    <textarea
                        name="site_sale_description"
                        rows="2"
                        data-preview="sale-description"
                    ><?= e($editorValue('site_sale_description')) ?></textarea>
                </label>
                <label>
                    Teks tombol
                    <input
                        type="text"
                        name="site_sale_button"
                        value="<?= e($editorValue('site_sale_button')) ?>"
                        data-preview="sale-button"
                    >
                </label>
                <label>
                    Tujuan tombol
                    <input
                        type="text"
                        name="site_sale_link"
                        value="<?= e($editorValue('site_sale_link')) ?>"
                        placeholder="books"
                    >
                </label>
                <label class="site-editor-wide">
                    Gambar promo (JPG, PNG, WEBP · maks. 4 MB)
                    <input
                        type="file"
                        name="sale_image"
                        accept="image/jpeg,image/png,image/webp"
                        data-preview-image="sale-preview-image"
                    >
                </label>
            </div>
        </section>

        <section class="admin-panel site-editor-section" id="new-editor">
            <div class="panel-heading">
                <div>
                    <h2><?= ui_icon('book-open') ?> Promo Buku Baru</h2>
                    <p>Atur kartu koleksi atau rilis buku terbaru.</p>
                </div>
            </div>
            <label class="site-editor-switch">
                <input
                    type="checkbox"
                    name="site_new_enabled"
                    value="1"
                    <?= $editorValue('site_new_enabled') === '1' ? 'checked' : '' ?>
                    data-preview-toggle="new-preview"
                >
                <span>Tampilkan promo buku baru</span>
            </label>
            <div class="site-editor-fields">
                <label>
                    Label kecil
                    <input
                        type="text"
                        name="site_new_label"
                        value="<?= e($editorValue('site_new_label')) ?>"
                        data-preview="new-label"
                    >
                </label>
                <label>
                    Judul promo
                    <input
                        type="text"
                        name="site_new_title"
                        value="<?= e($editorValue('site_new_title')) ?>"
                        data-preview="new-title"
                    >
                </label>
                <label class="site-editor-wide">
                    Deskripsi
                    <textarea
                        name="site_new_description"
                        rows="2"
                        data-preview="new-description"
                    ><?= e($editorValue('site_new_description')) ?></textarea>
                </label>
                <label>
                    Teks tombol
                    <input
                        type="text"
                        name="site_new_button"
                        value="<?= e($editorValue('site_new_button')) ?>"
                        data-preview="new-button"
                    >
                </label>
                <label>
                    Tujuan tombol
                    <input
                        type="text"
                        name="site_new_link"
                        value="<?= e($editorValue('site_new_link')) ?>"
                        placeholder="books?sort=new"
                    >
                </label>
                <label class="site-editor-wide">
                    Gambar promo (JPG, PNG, WEBP · maks. 4 MB)
                    <input
                        type="file"
                        name="new_image"
                        accept="image/jpeg,image/png,image/webp"
                        data-preview-image="new-preview-image"
                    >
                </label>
            </div>
        </section>

        <section class="admin-panel site-editor-section" id="about-editor">
            <div class="panel-heading">
                <div>
                    <h2><?= ui_icon('info') ?> Halaman Tentang Kami</h2>
                    <p>Ubah cerita, visi, misi, kutipan, dan foto pengantar.</p>
                </div>
            </div>
            <div class="site-editor-fields">
                <label>
                    Label kecil
                    <input
                        type="text"
                        name="site_about_eyebrow"
                        value="<?= e($editorValue('site_about_eyebrow')) ?>"
                        data-preview="about-eyebrow"
                    >
                </label>
                <label>
                    Judul halaman
                    <input
                        type="text"
                        name="site_about_title"
                        value="<?= e($editorValue('site_about_title')) ?>"
                        data-preview="about-title"
                    >
                </label>
                <label class="site-editor-wide">
                    Deskripsi pembuka
                    <textarea
                        name="site_about_intro"
                        rows="2"
                        data-preview="about-intro"
                    ><?= e($editorValue('site_about_intro')) ?></textarea>
                </label>
                <label>
                    Judul cerita
                    <input
                        type="text"
                        name="site_about_story_title"
                        value="<?= e($editorValue('site_about_story_title')) ?>"
                        data-preview="about-story-title"
                    >
                </label>
                <label>
                    Bagian yang diedit
                    <input type="text" value="Cerita, visi, dan misi" disabled>
                </label>
                <label class="site-editor-wide">
                    Cerita Lumière Books
                    <textarea
                        name="site_about_story"
                        rows="5"
                        data-preview="about-story"
                    ><?= e($editorValue('site_about_story')) ?></textarea>
                </label>
                <label class="site-editor-wide">
                    Visi
                    <textarea
                        name="site_about_vision"
                        rows="3"
                        data-preview="about-vision"
                    ><?= e($editorValue('site_about_vision')) ?></textarea>
                </label>
                <label class="site-editor-wide">
                    Misi (satu poin per baris)
                    <textarea
                        name="site_about_mission"
                        rows="4"
                        data-preview="about-mission"
                    ><?= e($editorValue('site_about_mission')) ?></textarea>
                </label>
                <label class="site-editor-wide">
                    Kutipan penutup
                    <textarea
                        name="site_about_quote"
                        rows="2"
                        data-preview="about-quote"
                    ><?= e($editorValue('site_about_quote')) ?></textarea>
                </label>
                <label class="site-editor-wide">
                    Foto Tentang Kami (JPG, PNG, WEBP · maks. 4 MB)
                    <input
                        type="file"
                        name="about_image"
                        accept="image/jpeg,image/png,image/webp"
                        data-preview-image="about-preview-image"
                    >
                </label>
            </div>
        </section>

        <div class="site-editor-actions">
            <a
                class="button button-secondary"
                href="<?= e(url('home')) ?>"
                target="_blank"
                rel="noopener"
            >
                <?= ui_icon('external-link') ?> Buka Website
            </a>
            <button class="button button-primary" type="submit">
                <?= ui_icon('save') ?> Simpan Perubahan
            </button>
        </div>
    </form>

    <aside class="site-editor-preview-wrap">
        <div class="site-editor-preview-sticky">
            <div class="site-editor-preview-heading">
                <div>
                    <span class="eyebrow">PRATINJAU LANGSUNG</span>
                    <h2>Perubahan tampilan</h2>
                </div>
                <span class="site-editor-live-dot">● LANGSUNG</span>
            </div>
            <div class="site-preview-site">
                <div class="site-preview-brand">
                    <span class="site-preview-mark">✦</span>
                    <strong>Lumière Books</strong>
                    <small>Setiap Buku, Sejuta Cahaya.</small>
                </div>
                <section class="site-preview-hero" id="hero-preview">
                    <img
                        id="hero-preview-image"
                        src="<?= e($editorImage('hero')) ?>"
                        alt="Pratinjau banner"
                    >
                    <div class="site-preview-hero-copy">
                        <small data-preview-target="hero-eyebrow">
                            <?= e($editorValue('site_hero_eyebrow')) ?>
                        </small>
                        <h2 data-preview-target="hero-title">
                            <?= e($editorValue('site_hero_title')) ?>
                        </h2>
                        <h3 data-preview-target="hero-subtitle">
                            <?= e($editorValue('site_hero_subtitle')) ?>
                        </h3>
                        <p data-preview-target="hero-description">
                            <?= e($editorValue('site_hero_description')) ?>
                        </p>
                    </div>
                </section>
                <div class="site-preview-promo-title">Pilihan Lumière Books</div>
                <div class="site-preview-promos">
                    <article class="site-preview-promo" id="sale-preview">
                        <img
                            id="sale-preview-image"
                            src="<?= e($editorImage('sale')) ?>"
                            alt=""
                        >
                        <div>
                            <small data-preview-target="sale-label">
                                <?= e($editorValue('site_sale_label')) ?>
                            </small>
                            <h3 data-preview-target="sale-title">
                                <?= e($editorValue('site_sale_title')) ?>
                            </h3>
                            <p data-preview-target="sale-description">
                                <?= e($editorValue('site_sale_description')) ?>
                            </p>
                            <span data-preview-target="sale-button">
                                <?= e($editorValue('site_sale_button')) ?>
                            </span>
                        </div>
                    </article>
                    <article class="site-preview-promo" id="new-preview">
                        <img
                            id="new-preview-image"
                            src="<?= e($editorImage('new')) ?>"
                            alt=""
                        >
                        <div>
                            <small data-preview-target="new-label">
                                <?= e($editorValue('site_new_label')) ?>
                            </small>
                            <h3 data-preview-target="new-title">
                                <?= e($editorValue('site_new_title')) ?>
                            </h3>
                            <p data-preview-target="new-description">
                                <?= e($editorValue('site_new_description')) ?>
                            </p>
                            <span data-preview-target="new-button">
                                <?= e($editorValue('site_new_button')) ?>
                            </span>
                        </div>
                    </article>
                </div>
                <div class="site-preview-about">
                    <img
                        id="about-preview-image"
                        src="<?= e($editorImage('about')) ?>"
                        alt=""
                    >
                    <div>
                        <small>TENTANG KAMI</small>
                        <h3 data-preview-target="about-story-title">
                            <?= e($editorValue('site_about_story_title')) ?>
                        </h3>
                        <p data-preview-target="about-story">
                            <?= e($editorValue('site_about_story')) ?>
                        </p>
                    </div>
                </div>
                <div class="site-preview-about-copy">
                    <small data-preview-target="about-eyebrow">
                        <?= e($editorValue('site_about_eyebrow')) ?>
                    </small>
                    <h3 data-preview-target="about-title">
                        <?= e($editorValue('site_about_title')) ?>
                    </h3>
                    <p data-preview-target="about-intro">
                        <?= e($editorValue('site_about_intro')) ?>
                    </p>
                    <strong>Visi</strong>
                    <p data-preview-target="about-vision">
                        <?= e($editorValue('site_about_vision')) ?>
                    </p>
                    <strong>Misi</strong>
                    <p data-preview-target="about-mission">
                        <?= e($editorValue('site_about_mission')) ?>
                    </p>
                    <blockquote data-preview-target="about-quote">
                        <?= e($editorValue('site_about_quote')) ?>
                    </blockquote>
                </div>
            </div>
            <p class="site-editor-preview-help">
                Pratinjau ini mengikuti perubahan teks dan gambar yang kamu pilih.
                Hasil di website pelanggan diperbarui setelah disimpan.
            </p>
        </div>
    </aside>
</div>
